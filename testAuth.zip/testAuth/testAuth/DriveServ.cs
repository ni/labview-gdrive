﻿using Google.Apis.Drive.v3;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using Google.Apis.Auth.OAuth2;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace Driver
{


    public class Driver
    {

        public static IEnumerable<string> sillyTypeCaster(String[] input)
        {
            return input;
        }
    
        public static String secretPath(String pathName)
        {
            //this string will become the path for the fileStream
            return pathName;
        }
    public static string[] scopes = { DriveService.Scope.Drive};

       public static string appName = "tester";

        public static DriveService DriveServ(String path)
        {
            UserCredential cred;
            
            using (var stream =
                  new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                string credPath = System.Environment.GetFolderPath(
                    System.Environment.SpecialFolder.Personal);
                credPath = Path.Combine(credPath, ".credentials/drive-dotnet-quickstart.json");

                cred = GoogleWebAuthorizationBroker.AuthorizeAsync(
                    GoogleClientSecrets.Load(stream).Secrets,
                    scopes,
                    "user",
                    CancellationToken.None,
                    new FileDataStore(credPath, true)).Result;
                


                // Create Drive API service.
                var service = new DriveService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = cred,
                    ApplicationName = appName,
                });

                return service;
            }
        }

                         
        }
       
           

    }


